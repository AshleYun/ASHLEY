from account import *
from imap_tools import Mailbox

with Mailbox("imap.gmail.com",993).login(EMAIL_ADDRESS, EMAIL_PASSWORD, initial_folder"INBOX")  as mailbox :
    index = 1
    for msg in mailbox.fetch('(SENTSINCE 07-Nov-2020)') : 
        if "파이썬 특강" in msg.subject:
            nickname, phone = msg.text.plit("/")
            print("순번 : {} 닉네임 : {} 전화번호 : {}".format(index, nickname,phone))
            index += 1
