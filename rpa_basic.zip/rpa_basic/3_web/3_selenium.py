from selenium import webdriver

#browser = webdriver.Chrome("./chromedriver.exe")

browser = webdriver.Chrome()

browser.get("http://naver.com")

