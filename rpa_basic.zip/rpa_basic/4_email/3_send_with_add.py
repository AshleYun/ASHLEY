import smtplib
from account import *
from email.message import EmailMessage

msg = EmailMessage()
msg["Subject"] = "테스트 메일입니다."
msg["From"] = EMAIL_ADDRESS
msg["To"] = "dlfp855@naver.com"
msg.set_content("테스트")

with open("btn_brush.png","rb") as f:
    msg.add_attachment(f.read(), maintype= "Image", subtype="png", filename = f.name)

# #with open("테스트.xlsx","rb") as f:
# msg.add_attachment(f.read(),maintype="application",subtype = "octet-stream")

# #with open("테스트.pdf","rb") as f:
# msg.add_attachment(f.read(),maintype="application",subtype = "pdf")

with smtplib.SMTP("smtp.naver.com",587) as smtp:
    smtp.ehlo()
    smtp.starttls()
    smtp.login(EMAIL_ADDRESS,EMAIL_PASSWORD)
    smtp.send_message(msg)

#