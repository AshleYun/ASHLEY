import pyautogui
#print("곧 시작합니다...")
# pyautogui.countdown(3)
# print("자동화 시작")

# pyautogui.alert("자동화 수행에 실패하엿습니다.", "경고")
# pyautogui.confirm("계속진행함?", "확인")

# result = pyautogui.prompt("파일명을 무엇으로 하시겟습니까?", "입력")
# print(result)

result = pyautogui.password("파일명을 무엇으로 하시겟습니까?", "입력")
print(result)