
import pyautogui


w = pyautogui.getWindowsWithTitle ("제목 없음") [0]
w.activate()

# pyautogui.write("12345")
# pyautogui.write("Nado", interval=0.25)

pyautogui.write(["t","e","s","t","left","left","right","l","a","enter"],interval=0.25)

# 특수문자
# shift 4 > $
pyautogui.keyDown("shift")
pyautogui.press("4")
pyautogui.keyUp("shift")

#조합키
pyautogui.keyDown("ctrl")
pyautogui.keyDown("a")
pyautogui.keyUp("a")
pyautogui.keyUp("ctrl")

#간편 조합키 - 전부 누르고 전부 떼고
pyautogui.hotkey("ctrl","alt","shift","a")
