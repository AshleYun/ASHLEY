import pyautogui
file_menu = pyautogui.locateOnScreen("file_menu.png")
print(file_menu)
pyautogui.click(file_menu)

#locateAllonScreen 동일한 이미지 모두 클릭
#locateOnScreen 첫번째 스크린만 클릭

# trash_icon = pyautogui.locationOnscreen("trash_icon.png")
# pyautogui.moveTo(trash_icon)

# 속도 개선
# 1.GrayScale - 여러가지 문서가 흑백으로 전환/ 속도가 개선됨/단, 정확도가 조금 떨어짐

# trash_icon = pyautogui.locationOnscreen("trash_icon.png", grayscale= True)
# pyautogui.moveTo(trash_icon)



# 2. 범위지정 - 범위를 좁혀주면 빠르게 자동화 가능
#trash_icon = pyautogui.locationOnscreen("trash_icon.png", region=(x,y,width,height))
#pyautogui.moveTo(trash_icon)

#pyautogui.mouseInfo()
#좌표값 찍고


# 3. 정확도 조정


