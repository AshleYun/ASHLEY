import pyautogui
pyautogui.sleep(3) # 3초 대기
# print(pyautogui.position())

#pyautogui.click(64.17, duration=1) #1초 동안 좌표로 이동 후에 마우스 클릭
#pyautogui.click()
#pyautogui.mouseDown()
#pyautogui.mouseUp()

#pyautogui.doubleClick()
pyautogui.click(clicks = 500)