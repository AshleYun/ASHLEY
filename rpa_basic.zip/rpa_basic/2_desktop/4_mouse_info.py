import pyautogui
pyautogui.FAILSAFE = False
#pyautogui.mouseInfo()

for i in range(5) :
    pyautogui.move(100,100)
    pyautogui.sleep(1)

